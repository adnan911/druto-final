# Druto Seller Integration Kit

This bundle helps a new seller integrate **USDC payments on Arc Testnet** with Druto. It includes the standalone SDK, a copy-paste Next.js starter, seller onboarding documentation, webhook guidance, and Arc Testnet setup notes.

## Start here

1. Read `docs/NEW_SELLER_START_GUIDE.md` for the complete onboarding path.
2. Open the Druto dashboard and register the seller, receiving wallet, API key, and webhook endpoint.
3. Use `nextjs-starter/` if the website uses Next.js.
4. Use `sdk/` when integrating Druto into another Node.js or TypeScript backend.
5. Keep `DRUTO_API_KEY` and `DRUTO_WEBHOOK_SECRET` on the server only.
6. Fulfill orders only after verifying the signed `payment.verified` webhook or a trusted server-side payment status.

## Bundle contents

| Path | Purpose |
| --- | --- |
| `sdk/` | Standalone `@druto/sdk` source, compiled distribution, examples, tests, README, and detailed guide. |
| `nextjs-starter/` | Copy-paste Next.js starter with server-side Payment Intent creation, hosted checkout, webhook verification, and return page. |
| `docs/NEW_SELLER_START_GUIDE.md` | Beginner-friendly seller onboarding and integration instructions. |
| `docs/real-arc-testnet-setup.md` | Arc Testnet and USDC setup notes. |

## Current network boundary

The included examples target **Arc Testnet** and **USDC only**. Use a disposable test wallet for demos. Do not add seed phrases or private keys to this bundle, your website repository, browser code, or environment variables prefixed with `NEXT_PUBLIC_` or `VITE_`.

## Validation

The SDK tests pass with 10 tests. The Next.js starter passes TypeScript validation. The platform’s seller onboarding and webhook contracts are covered by the Druto platform test suite.

## Production work before mainnet

Before production use, configure the correct mainnet asset and chain values, rotate testnet credentials, enforce API-key scopes and expiration, use an HTTPS webhook endpoint, add durable webhook-event storage, and complete a real operational reconciliation runbook.
